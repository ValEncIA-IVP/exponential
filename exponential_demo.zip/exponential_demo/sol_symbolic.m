%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gridded reference solution for "ODE_complex.m"
%
% Authors: Andreas Rauh, Luise Senkel
% {andreas.rauh,luise.senkel}@uni-rostock.de
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sol_symbolic(t_vec)

syms sigma_1 omega_1 t real
syms x01 x02 real

A_real = [ sigma_1 omega_1;
    -omega_1 sigma_1];

x0 = [x01; x02];

x = simple(expm(A_real*t)*x0);

t = t_vec;

NO_GRID_POINTS = 10;

x1_vec  = linspace(0.9,1.1,NO_GRID_POINTS);
x2_vec  = linspace(0.9,1.1,NO_GRID_POINTS);
omega_1 = 1.0;
sigma_1 = -3.0;

[x1_vec, x2_vec] = ndgrid(x1_vec, x2_vec);
x1_vec = x1_vec(:);
x2_vec = x2_vec(:);

x1_sol = vectorize(x(1));
x2_sol = vectorize(x(2));

for i=1:length(x1_vec),
    x01 = x1_vec(i);
    x02 = x2_vec(i);


    figure(1);
    hold on;
    plot(t,eval(x1_sol),'color',[0.8 0.8 0.8]);
    hold off;

    figure(2);
    hold on;
    plot(t,eval(x2_sol),'color',[0.8 0.8 0.8]);
    hold off;
end;