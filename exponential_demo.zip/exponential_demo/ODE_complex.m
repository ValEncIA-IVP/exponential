%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Complex-valued iteration for solving IVPs
%
% Authors: Andreas Rauh, Luise Senkel
% {andreas.rauh,luise.senkel}@uni-rostock.de
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all

clc;

startintlab;
format long

y_inf = [];
y_sup = [];

T = 0;

% specification of the discretization step size
tmax = 0.01;

% time vector
t_vec = [0];


% uncertain (real-valued) initial states
x0 = [1; 1]*infsup(0.9,1.1); 

% Real-valued system model
a = -3; 
b = -1; 
A_real = [a -b; b a];
[v,d] = eig(mid(A_real));
T_mat = intval(v);
inv_T_mat = inv(intval(v));

% Transformation into complex Jordan canonical form
A = inv_T_mat*A_real*T_mat;

% Transformation of the initial states: NOTE Verified computation of matrix
% the inverse is necessary: Circles represent overapproximation of original
% rectangular box
x0 = inv_T_mat*x0;

% Run for a fixed numer of 500 time steps
for zz=1:500,
    zz
    t = infsup(0,tmax);
    
    % initial enclosure for eigenvalues (can be determined automatically by
    % using the Gershgorin circle theorem)
    a_r = infsup(-2,-0.5)*2;
    a_i = infsup(0.5,2);
    
    Lambda = [a_r+1j*a_i; a_r-1j*a_i];
    Lambda_tmp = Lambda;
    
    valid = 0;
    
    x_encl_tmp = x0;
    
    % Max. 50 iterations per time step
    for i = 1:50,
        
        x_encl_tmp = diag(exp(Lambda_tmp*t))*x0;
        
        for j = 1:length(x0),
            xx_temp = x_encl_tmp./x_encl_tmp(j);
            xx_temp(j) = 1;
            temp_var = A(j,:)*xx_temp;
            Lambda_tmp1(j,1) = temp_var;
        end;
        
        indx_in = in(Lambda_tmp1, Lambda_tmp);
        
        if all(indx_in),
            Lambda_tmp = Lambda_tmp1;
            valid = 1;
            
            Lambda = Lambda_tmp;
            
            % break if improvement is smaller than the given tolerance
            if norm(diam(Lambda_tmp1)-diam(Lambda_tmp))<1e-6,
                break;
            end;
        else
            Lambda_tmp(indx_in) = Lambda_tmp1(indx_in);
            Lambda_tmp(~indx_in) = Lambda_tmp(~indx_in)+infsup(-0.1,0.1)*randn+1j*infsup(-0.1,0.1)*randn; 
            Lambda_tmp(~indx_in) = hull(Lambda_tmp1(~indx_in),Lambda_tmp1(~indx_in));
        end;
    end;
    
    % Stop if no verified solution can be found in the giben number of
    % iterations with a fixed integration step size
    if (valid==0),
        break;
        error('no valid solution found');
    end;

    diag_mat = diag(exp(Lambda*tmax));
    for i = 1:length(x0),
        x0_tmp(i,1) = diag_mat(i,:)*x0;
    end;
    
    x0 = x0_tmp;
    
    % store the complex-valued result
    x_vec(:,zz) = x0;
    
end;

% backward transformation into original real-valued coordinates
x_real = intval([]);
for i = 1:size(x_vec,2),
    x_real(:,i) = real(T_mat*x_vec(:,i));
end;

% visualization

% compute gridded reference
t_vec = [0:size(x_vec,2)-1]*tmax;

sol_symbolic(t_vec);

figure(1);
hold on;
plot(t_vec,inf(x_real(1,:)),'k','LineWidth',2);
plot(t_vec,sup(x_real(1,:)),'k','LineWidth',2);
hold off;
set(gca,'XLim',[0 t_vec(end)]);
set(gca,'YLim',[-0.2 1.2]);
xlabel('time')
ylabel('x_1(t)')

figure(2);
hold on;
plot(t_vec,inf(x_real(2,:)),'k','LineWidth',2);
plot(t_vec,sup(x_real(2,:)),'k','LineWidth',2);
hold off;
set(gca,'XLim',[0 t_vec(end)]);
set(gca,'YLim',[-0.2 1.2]);
xlabel('time')
ylabel('x_2(t)')